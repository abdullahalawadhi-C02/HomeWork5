package com.example.almn8thapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.almn8thapp.ui.login.LoginActivity;

public class Rigester extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.rigester);
        final Button register = findViewById(R.id.Register2);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Rigester.this, LoginActivity.class);
                startActivity(intent);
            }
        });

    }
}