package com.example.almn8thapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class the_code_page extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_the_code_page);
        final TextView code = findViewById(R.id.textView8);
        code.setText(getIntent().getStringExtra("code"));
    }
}