package com.example.almn8thapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class disain extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.disain);
        //arry
        ArrayList<disainClass> NameDisain = new ArrayList<>();
        disainClass calor = new disainClass("change calor","easy","java","","");
        disainClass layout = new disainClass("change Layout","easy","java","","");
        disainClass img = new disainClass("Add Imag","easy","java","","");
        disainClass background = new disainClass("Add Background","easy","java","","");
        disainClass Margin = new disainClass("margin","easy","java","","");
        disainClass ScrollPage = new disainClass("Add Scroll Page","easy","java","","");
        disainClass TextViewAndEditText = new disainClass("change calor","easy","java","","");
        disainClass Button = new disainClass("Add Button","easy","java","","");
        disainClass NewPage = new disainClass("New Page","easy","java","","");
        disainClass NewClass = new disainClass("New Class","easy","java","","");
        //add title to arry
        NameDisain.add(calor);//0
        NameDisain.add(layout);//1
        NameDisain.add(img);//2
        NameDisain.add(background);//3
        NameDisain.add(Margin);//4
        NameDisain.add(ScrollPage);//5
        NameDisain.add(TextViewAndEditText);//6
        NameDisain.add(Button);//7
        NameDisain.add(NewPage);//8
        NameDisain.add(NewClass);//9
        //ترتيب
        RecyclerView disain = findViewById(R.id.recyclerview);
        disain.setHasFixedSize(true);
        RecyclerView.LayoutManager lm = new LinearLayoutManager(this);
        disain.addItemDecoration(new DividerItemDecoration(this,DividerItemDecoration.HORIZONTAL));
        disain.setLayoutManager(lm);
        disainAdopter disains =new disainAdopter(NameDisain,this);
        disain.setAdapter(disains);
    }
}