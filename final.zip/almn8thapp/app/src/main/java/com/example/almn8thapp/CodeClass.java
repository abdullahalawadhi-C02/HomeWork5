package com.example.almn8thapp;

import java.io.Serializable;

public class CodeClass implements Serializable {
    String code;
    String dificalt;
    String codes;
    int imgCode;
    String viedio;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDificalt() {
        return dificalt;
    }

    public void setDificalt(String dificalt) {
        this.dificalt = dificalt;
    }

    public String getCodes() {
        return codes;
    }

    public void setCodes(String codes) {
        this.codes = codes;
    }

    public int getImgCode() {
        return imgCode;
    }

    public void setImgCode(int imgCode) {
        this.imgCode = imgCode;
    }

    public String getViedio() {
        return viedio;
    }

    public void setViedio(String viedio) {
        this.viedio = viedio;
    }

    public CodeClass(String code, String dificalt, String codes, int imgCode, String viedio) {
        this.code = code;
        this.dificalt = dificalt;
        this.codes = codes;
        this.imgCode = imgCode;
        this.viedio = viedio;
    }
}


