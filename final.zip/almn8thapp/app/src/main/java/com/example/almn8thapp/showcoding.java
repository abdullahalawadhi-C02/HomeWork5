package com.example.almn8thapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class showcoding extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_showcoding);
        //bundle
        Bundle one =getIntent().getExtras();
       final CodeClass tr = (CodeClass) one.getSerializable("code");
        //t3ref
        ImageView CodePicthure = findViewById(R.id.imageView5);
        TextView TheCode = findViewById(R.id.textView6);
        //class thing
        CodePicthure.setImageResource(tr.getImgCode());

        TheCode.setText(tr.getCodes());
        //another page here code
        TheCode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(tr.getCode().equals("Activity Button")) {
                    Intent intent = new Intent(showcoding.this, the_code_page.class);
                    intent.putExtra("code","\n" +
                            "  final Button Contact = findViewById(R.id.button3);\n" +
                            " Contact.setOnClickListener(new View.OnClickListener() {\n" +
                            " @Override\n" +
                            " public void onClick(View view) {\n" +
                            " Intent intent = new Intent(MainActivity.this, MainActivity2.class);\n" +
                            " startActivity(intent);\n" +
                            " }\n" +
                            " });");
                    startActivity(intent);
                }
                else if(tr.getCode().equals("Calculator")) {
                    Intent intent = new Intent(showcoding.this,the_code_page.class);
                    intent.putExtra("code","        //t3ref\n" +
                            " final EditText number1 = findViewById(R.id.editTextTextPersonName);\n" +
                            " final EditText number2 = findViewById(R.id.editTextTextPersonName3);\n" +
                            " final Button add = findViewById(R.id.bottom);\n" +
                            " //do the jam3\n" +
                            " add.setOnClickListener(new View.OnClickListener() {\n" +
                            " @Override\n" +
                            " public void onClick(View view) {\n" +
                            " int n1 =Integer.parseInt(number1.getText().toString());\n" +
                            " int n2 = Integer.parseInt(number2.getText().toString());\n" +
                            " int sum = n1 + n2;\n" +
                            " //toast\n" +
                            " Toast.makeText(MainActivity.this,sum + \"\",Toast.LENGTH_SHORT).show();\n" +
                            " }\n" +
                            " });\n" +
                            " }\n" +
                            " }"
               );
                    startActivity(intent);
                }
                else if(tr.getCode().equals("Jam3")) {
                    Intent intent = new Intent(showcoding.this,the_code_page.class);
                    intent.putExtra("code","        //t3ref\n" +
                            "  final EditText number1 = findViewById(R.id.editTextTextPersonName);\n" +
                            "  final EditText number2 = findViewById(R.id.editTextTextPersonName3);\n" +
                            "  final Button add = findViewById(R.id.bottom);\n" +
                            "  //do the jam3\n" +
                            "  add.setOnClickListener(new View.OnClickListener() {\n" +
                            "  @Override\n" +
                            "  public void onClick(View view) {\n" +
                            " int n1 =Integer.parseInt(number1.getText().toString());\n" +
                            " int n2 = Integer.parseInt(number2.getText().toString());\n" +
                            " int sum = n1 + n2;\n" +
                            " //toast\n" +
                            " Toast.makeText(MainActivity.this,sum + \"\",Toast.LENGTH_SHORT).show();\n" +
                            " }\n" +
                            " });\n" +
                            " }\n" +
                            " }");
                    startActivity(intent);
                }
                else if(tr.getCode().equals("Arry")) {
                    Intent intent = new Intent(showcoding.this,the_code_page.class);
                    intent.putExtra("code","  Button backBtn;\n" +
                            "        String facts[] = {\n" +
                            "    \"قُلْ أَعُوذُ بِرَبِّ ٱلْفَلَقِ، مِن شَرِّ مَا خَلَقَ، وَمِن شَرِّ غَاسِقٍ إِذَا وَقَبَ، وَمِن شَرِّ ٱلنَّفَّٰثَٰتِ فِى ٱلْعُقَدِ، وَمِن شَرِّ حَاسِدٍ إِذَا حَسَدَ\",\n " +
                            "            \"قُلْ أَعُوذُ بِرَبِّ ٱلنَّاسِ، مَلِكِ ٱلنَّاسِ، إِلَٰهِ ٱلنَّاسِ، مِن شَرِّ ٱلْوَسْوَاسِ ٱلْخَنَّاسِ، ٱلَّذِى يُوَسْوِسُ فِى صُدُورِ ٱلنَّاسِ، مِنَ ٱلْجِنَّةِ وَٱلنَّاسِ\",\n " +
                            "          \"أَصْـبَحْنا وَأَصْـبَحَ المُـلْكُ لله وَالحَمدُ لله ، لا إلهَ إلاّ اللّهُ وَحدَهُ لا شَريكَ لهُ، لهُ المُـلكُ ولهُ الحَمْـد، وهُوَ على كلّ شَيءٍ قدير ، رَبِّ أسْـأَلُـكَ خَـيرَ ما في هـذا اليوم وَخَـيرَ ما بَعْـدَه ، وَأَعـوذُ بِكَ مِنْ شَـرِّ ما في هـذا اليوم وَشَرِّ ما بَعْـدَه، رَبِّ أَعـوذُبِكَ مِنَ الْكَسَـلِ وَسـوءِ الْكِـبَر ، رَبِّ أَعـوذُ بِكَ مِنْ عَـذابٍ في النّـارِ وَعَـذابٍ في القَـبْر\"\n " +
                            " };      final TextView v = findViewById(R.id.textView2);\n" +
                            " final Button n = findViewById(R.id.button3);\n" +
                            " View.OnClickListener onClickListener = new  View.OnClickListener(){\n" +
                            " \n" +
                            " \n" +
                            " @Override\n" +
                            " public void onClick(View view) {\n" +
                            " Random randomgen = new Random();\n" +
                            " int randomNumber = randomgen.nextInt(3);\n" +
                            " String fact = facts[randomNumber];\n" +
                            " v.setText(fact);\n" +
                            " }\n" +
                            " };\n" +
                            " n.setOnClickListener(onClickListener);");
                    startActivity(intent);
                }
                else if(tr.getCode().equals("Arry list")) {
                    Intent intent = new Intent(showcoding.this,the_code_page.class);
                    intent.putExtra("code"," we need (1class),(3java),(build.gradle)\n" +
                            " ////////\n" +
                            " (class)\n" +
                            " public class pokemon implements Serializable {\n" +
                            " String name;\n" +
                            " int image;\n" +
                            " int attack;\n" +
                            " int defence;\n" +
                            " int total;\n" +
                            " public String getName() {\n" +
                            " return name;\n" +
                            " }\n" +
                            " public void setName(String name) {\n" +
                            " this.name = name;\n" +
                            " }\n" +
                            " public int getImage() {\n" +
                            " return image;\n" +
                            " }\n" +
                            " public void setImage(int image) {\n" +
                            " this.image = image;\n" +
                            " }\n" +
                            " public int getAttack() {\n" +
                            " return attack;\n" +
                            " }\n" +
                            " public void setAttack(int attack) {\n" +
                            " this.attack = attack;\n" +
                            " }\n" +
                            " public int getDefence() {\n" +
                            " return defence;\n" +
                            " }\n" +
                            " public void setDefence(int defence) {\n" +
                            " this.defence = defence;\n" +
                            " }\n" +
                            " public int getTotal() {\n" +
                            " return total;\n" +
                            " }\n" +
                            " public void setTotal(int total) {\n" +
                            " this.total = total;\n" +
                            " }\n" +
                            " public pokemon(String name, int image, int attack, int defence, int total) {\n" +
                            " this.name = name;\n" +
                            " this.image = image;\n" +
                            " this.attack = attack;\n" +
                            " this.defence = defence;\n" +
                            " this.total = total;\n" +
                            " }\n" +
                            " }\n" +
                            " ///////////////\n" +
                            " (java1)\n" +
                            " class pokemonAdapter  extends RecyclerView.Adapter {\n" +
                            " ArrayList<pokemon>poArry;\n" +
                            " Context context;\n" +
                            " public pokemonAdapter(ArrayList<pokemon> poArry, Context context) {\n" +
                            " this.poArry = poArry;\n" +
                            " this.context = context;\n" +
                            " }\n" +
                            " @NonNull\n" +
                            " @Override\n" +
                            " public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {\n" +
                            " View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.pokemon1,parent,false);\n" +
                            " ViewHolder vh = new ViewHolder(v);\n" +
                            " return vh;\n" +
                            " }\n" +
                            " @Override\n" +
                            " public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, final int position) {\n" +
                            " ((ViewHolder)holder).image.setImageResource(poArry.get(position).getImage());\n" +
                            " ((ViewHolder)holder).name.setText(poArry.get(position).getName()+\"\");\n" +
                            " ((ViewHolder)holder).view.setOnClickListener(new View.OnClickListener() {\n" +
                            "  @Override\n" +
                            " public void onClick(View view) {\n" +
                            " Intent i = new Intent(context,MainActivity2.class);\n" +
                            " i.putExtra(\"pokemon\",poArry.get(position));\n" +
                            " context.startActivity(i); }\n" +
                            " });\n" +
                            " }\n" +
                            "@Override\n" +
                            " public int getItemCount() {\n" +
                            " return poArry.size();\n" +
                            " }\n" +
                            " public static class ViewHolder extends RecyclerView.ViewHolder{\n" +
                            " public ImageView image;\n" +
                            " public TextView name;\n" +
                            " public TextView total;\n" +
                            " public View view;\n" +
                            " public ViewHolder(@NonNull View itemView) {\n" +
                            " super(itemView);\n" +
                            " view = itemView;\n" +
                            " image = itemView.findViewById(R.id.imageView);\n" +
                            " name = itemView.findViewById(R.id.textView2);\n" +
                            " total = itemView.findViewById(R.id.textView3);\n" +
                            " }\n" +
                            " }\n" +
                            " }\n" +
                            " ////////////\n" +
                            " (java2)\n" +
                            "  ArrayList <pokemon> pokemonpall = new ArrayList<>();\n" +
                            " pokemon n = new pokemon(\"Bulbasaur\",R.drawable.venusaur,200,400,600);\n" +
                            " pokemon y = new pokemon(\" Ivysaur\",R.drawable.venusaur,100,600,700);\n" +
                            " pokemon t = new pokemon(\"Venusaur\",R.drawable.venusaur,300,500,800);\n" +
                            " pokemon r = new pokemon(\"Venusaur\",R.drawable.venusaur,300,500,800);\n" +
                            " pokemon o = new pokemon(\"Venusaur\",R.drawable.venusaur,300,500,800);\n" +
                            " pokemonpall.add(n);//0\n" +
                            " pokemonpall.add(y);//1\n" +
                            " pokemonpall.add(t);//2\n" +
                            " pokemonpall.add(t);//3\n" +
                            " pokemonpall.add(t);//4\n" +
                            " RecyclerView rv = findViewById(R.id.rec);\n" +
                            " rv.setHasFixedSize(true);\n" +
                            " RecyclerView.LayoutManager lm = new LinearLayoutManager(this);\n" +
                            " rv.addItemDecoration(new DividerItemDecoration(this,DividerItemDecoration.HORIZONTAL));\n" +
                            " rv.setLayoutManager(lm);  pokemonAdapter po =new pokemonAdapter(pokemonpall,this);\n" +
                            " rv.setAdapter(po);\n" +
                            " }\n" +
                            " }\n" +
                            " ////////////\\\n" +
                            " (java3)\n" +
                            "   Bundle b = getIntent().getExtras();\n" +
                            " pokemon p = (pokemon) b.getSerializable(\"pokemon\");\n" +
                            " ImageView img = findViewById(R.id.imageView2);\n" +
                            " TextView t = findViewById(R.id.textView4);\n" +
                            " TextView ti = findViewById(R.id.textView5);\n" +
                            " TextView tie = findViewById(R.id.textView6);\n" +
                            " img.setImageResource(p.getImage());\n" +
                            " t.setText(p.getName());\n" +
                            " ti.setText(\"Attack:\"+p.getAttack());\n" +
                            " tie.setText(\"Defence:\"+p.getDefence());\n" +
                            " }\n" +
                            " }\n" +
                            " ///////////// \n" +
                            " (build.gradle)\n" +
                            " implementation 'com.android.support:recyclerview-v7:28.0.0'");
                    startActivity(intent);
                }
                else if(tr.getCode().equals("Add Web Sit")) {
                    Intent intent = new Intent(showcoding.this,the_code_page.class);
                    intent.putExtra("code","        final ImageView m = findViewById(R.id.process);\n" +
                            " }\n" +
                            " public void process(View view) {\n" +
                            " Intent mab = new Intent(Intent.ACTION_VIEW);\n" +
                            " mab.setData(Uri.parse(\"https://www.google.com/maps/@29.3115846,48.0329508,15z\"));\n" +
                            " startActivity(mab);\n" +
                            " }");
                    startActivity(intent);
                }
                else if(tr.getCode().equals("print")) {
                    Intent intent = new Intent(showcoding.this,the_code_page.class);
                    intent.putExtra("code","final EditText q = findViewById(R.id.editTextTextPersonName);\n" +
                            " final EditText w = findViewById(R.id.editTextTextPersonName2);\n" +
                            " sumbet.setOnClickListener(new View.OnClickListener() {\n" +
                            " @Override\n" +
                            " public void onClick(View view) {\n" +
                            " Intent intent = new Intent(MainActivity6.this, MainActivity7.class);\n" +
                            " String qInEditText = q.getText().toString();\n" +
                            " String wInEditText = w.getText().toString();\n" +
                            " intent.putExtra(\"editTextTextPersonName\",qInEditText);\n" +
                            " intent.putExtra(\"editTextTextPersonName2\",wInEditText);\n" +
                            " startActivity(intent);\n" +
                            " }):(java1)\n" +
                            " ///////////////////////////\n" +
                            " super.onCreate(savedInstanceState);\n" +
                            " setContentView(R.layout.activity_main7);\n" +
                            " final TextView z = findViewById(R.id.textView29);\n" +
                            " final TextView x = findViewById(R.id.textView30);\n" +
                            " Bundle q = getIntent().getExtras();\n" +
                            " String a = q.getString(\"editTextTextPersonName\");\n" +
                            " z.setText(a);\n" +
                            " Bundle w = getIntent().getExtras();\n" +
                            " String f = w.getString(\"editTextTextPersonName2\");\n" +
                            " x.setText(f);\n" +
                            " (java2)");
                    startActivity(intent);
                }
                else if(tr.getCode().equals("Dailog")) {
                    Intent intent = new Intent(showcoding.this,the_code_page.class);
                    intent.putExtra("code"," AlertDialog.Builder Shahad = new AlertDialog.Builder(getActivity());\n" +
                            " Shahad.setTitle(\"Alert\")\n" +
                            " .setMessage(\"do want to apply\")\n" +
                            " .setPositiveButton(\"Agree\", new DialogInterface.OnClickListener() {\n" +
                            " @Override\n" +
                            " public void onClick(DialogInterface dialogInterface, int i) {\n" +
                            " Toast.makeText(getActivity(), \"Anoud\", Toast.LENGTH_SHORT).show();\n" +
                            " }\n" +
                            " });\n" +
                            " return Shahad.create();");
                    startActivity(intent);
                }
            }
        });

    }
}