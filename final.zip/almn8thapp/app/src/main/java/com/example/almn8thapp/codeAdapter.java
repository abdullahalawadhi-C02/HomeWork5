package com.example.almn8thapp;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class codeAdapter extends RecyclerView.Adapter {
         ArrayList<CodeClass>codeArry;
         Context context;
      public  codeAdapter(ArrayList<CodeClass> codeArry, Context context){
          this.codeArry = codeArry;
          this.context= context;
      }
    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View code = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_code_teach,parent,false);
        ViewHolder codes = new ViewHolder(code);
        return codes;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, final int position) {
        ((ViewHolder)holder).name.setText(codeArry.get(position).getCode());
        ((ViewHolder)holder).dificalt.setText(codeArry.get(position).getDificalt());
        ((ViewHolder)holder).view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent CodePage = new Intent(context,showcoding.class);
                CodePage.putExtra("code",codeArry.get(position));
                context.startActivity(CodePage);
            }
        });
    }

    @Override
    public int getItemCount() {return codeArry.size();}

    public static class ViewHolder extends RecyclerView.ViewHolder{
        public TextView name;
        public TextView dificalt;
        public View view;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            view = itemView;
            name = itemView.findViewById(R.id.textView3);
            dificalt = itemView.findViewById(R.id.textView4);
        }
    }
}
