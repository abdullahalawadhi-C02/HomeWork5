package com.example.almn8thapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.almn8thapp.ui.login.LoginActivity;

public class main extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        final Button Sign = findViewById(R.id.signIN);
        final Button rigester = findViewById(R.id.rigester);
        final Button visetor = findViewById(R.id.visiter);
        //
        Sign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(main.this, LoginActivity.class);
                startActivity(intent);
            }
        });
        rigester.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(main.this, Rigester.class);
                startActivity(intent);
            }
        });
        visetor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(main.this, chose.class);
                startActivity(intent);
            }
        });
    }
}