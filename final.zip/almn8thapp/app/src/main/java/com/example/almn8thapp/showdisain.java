package com.example.almn8thapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class showdisain extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_showdisain);
        //bundle
        Bundle sciend =getIntent().getExtras();
        disainClass di = (disainClass) sciend.getSerializable("disain");
        //t3ref
        TextView Thedisain = findViewById(R.id.textView7);
        //
    }
}