package com.example.almn8thapp;

import java.io.Serializable;

public class disainClass implements Serializable {
    String NameDisain;
    String difficalt;
    String disain;
    String imgdisain;
    String VideoDisain;

    public String getNameDisain() {
        return NameDisain;
    }

    public void setNameDisain(String nameDisain) {
        NameDisain = nameDisain;
    }

    public String getDifficalt() {
        return difficalt;
    }

    public void setDifficalt(String difficalt) {
        this.difficalt = difficalt;
    }

    public String getDisain() {
        return disain;
    }

    public void setDisain(String disain) {
        this.disain = disain;
    }

    public String getImgdisain() {
        return imgdisain;
    }

    public void setImgdisain(String imgdisain) {
        this.imgdisain = imgdisain;
    }

    public String getVideoDisain() {
        return VideoDisain;
    }

    public void setVideoDisain(String videoDisain) {
        VideoDisain = videoDisain;
    }

    public disainClass(String nameDisain, String difficalt, String disain, String imgdisain, String videoDisain) {
        NameDisain = nameDisain;
        this.difficalt = difficalt;
        this.disain = disain;
        this.imgdisain = imgdisain;
        VideoDisain = videoDisain;
    }
}
