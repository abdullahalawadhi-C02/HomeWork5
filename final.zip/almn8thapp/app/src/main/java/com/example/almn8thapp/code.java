package com.example.almn8thapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class code extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.code);
        //Arry
        ArrayList <CodeClass> code = new ArrayList<>();
       CodeClass ActivityButton = new CodeClass("Activity Button","Easy","java",R.drawable.img,"");
       CodeClass Calculator = new CodeClass("Calculator","Easy","java",R.drawable.img2,"");
       CodeClass Jam3 = new CodeClass("Jam3","Easy","java",R.drawable.img2,"");
       CodeClass Arry = new CodeClass("Arry","Easy","java",R.drawable.img4,"");
       CodeClass Arrylist = new CodeClass("Arry list","Med","java",R.drawable.img5,"");
       CodeClass AddaWebSit = new CodeClass ("Add Web Sit","Easy","java",R.drawable.img7,"");
       CodeClass print = new CodeClass("print","Med","java",R.drawable.img6,"");
       CodeClass Dailog = new CodeClass("Dailog","Med","java",R.drawable.img3,"");
        //add Arry
        code.add(ActivityButton);//0
        code.add(Calculator);//1
        code.add(Jam3);//2
        code.add(Arry);//3
        code.add(Arrylist);//4
        code.add(AddaWebSit);//5
        code.add(print);//6
        code.add(Dailog);//7
        //تراسي
        RecyclerView cods = findViewById(R.id.recyclerview);
        cods.setHasFixedSize(true);
        RecyclerView.LayoutManager lm = new LinearLayoutManager(this);
        cods.addItemDecoration(new DividerItemDecoration(this,DividerItemDecoration.HORIZONTAL));
        cods.setLayoutManager(lm);
        codeAdapter codes =new codeAdapter(code,this);
        cods.setAdapter(codes);
    }
}