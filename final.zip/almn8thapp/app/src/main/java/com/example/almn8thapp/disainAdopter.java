package com.example.almn8thapp;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class  disainAdopter extends RecyclerView.Adapter {
    ArrayList<disainClass>disainArry;
    Context context;

    public disainAdopter(ArrayList<disainClass> disainArry, Context context) {
        this.disainArry=disainArry;
        this.context=context;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View disains = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_disain_teach,parent,false);
        ViewHolder disain = new ViewHolder(disains);
        return disain;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, final int position) {
        ((ViewHolder)holder).name.setText(disainArry.get(position).getNameDisain());
        ((ViewHolder)holder).difficalt.setText(disainArry.get(position).getDifficalt());
        ((ViewHolder)holder).view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent disainPage = new Intent(context,showdisain.class);
                disainPage.putExtra("disain",disainArry.get(position));
                context.startActivity(disainPage);
            }
        });
    }

    @Override
    public int getItemCount() {return disainArry.size();}
    public static class ViewHolder extends RecyclerView.ViewHolder{
        public TextView name;
        public TextView difficalt;
        public View view;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            view = itemView;
            name = itemView.findViewById(R.id.textView);
            difficalt = itemView.findViewById(R.id.textView2);

        }
    }
}
